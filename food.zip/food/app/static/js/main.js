// ============================================
// NUTRITION TRACKER - MAIN JAVASCRIPT
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    console.log('NutriTracker initialized');
    
    // Smooth scroll for anchors
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
});

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('mealModal');
    if (event.target == modal) {
        modal.classList.remove('active');
    }
}

// Format number with 2 decimals
function formatNumber(num) {
    return (Math.round(num * 100) / 100).toFixed(2);
}

// Get nutrition data for a specific date
async function getNutritionData(date) {
    try {
        const response = await fetch(`/api/daily-nutrition/${date}`);
        if (response.ok) {
            return await response.json();
        }
    } catch (error) {
        console.error('Error fetching nutrition data:', error);
    }
    return null;
}

// Search foods
function searchFoods(query) {
    const food_list = document.getElementById('food_list');
    
    if (query.length < 2) {
        // Reset to showing all foods
        fetch(`/api/foods?limit=20`)
            .then(r => r.json())
            .then(foods => {
                food_list.innerHTML = '';
                foods.forEach(food => {
                    food_list.innerHTML += `
                        <div class="food-item" onclick="selectFood(${food.id}, '${food.name}', ${food.calories})">
                            <h4>${food.name}</h4>
                            <div class="food-calories">${food.calories} cal</div>
                            <div class="food-detail">
                                P: ${food.protein || 0}g | C: ${food.carbs || 0}g | F: ${food.fat || 0}g
                            </div>
                        </div>
                    `;
                });
            });
        return;
    }
    
    fetch(`/api/foods?search=${encodeURIComponent(query)}`)
        .then(r => r.json())
        .then(foods => {
            food_list.innerHTML = '';
            if (foods.length === 0) {
                food_list.innerHTML = '<p style="grid-column: 1/-1; text-align: center;">No foods found matching your search.</p>';
                return;
            }
            
            foods.forEach(food => {
                food_list.innerHTML += `
                    <div class="food-item" onclick="selectFood(${food.id}, '${food.name}', ${food.calories})">
                        <h4>${food.name}</h4>
                        <div class="food-calories">${food.calories} cal</div>
                        <div class="food-detail">
                            P: ${food.protein || 0}g | C: ${food.carbs || 0}g | F: ${food.fat || 0}g
                        </div>
                    </div>
                `;
            });
        })
        .catch(error => console.error('Error searching foods:', error));
}

// Add event listener to food search if it exists
const foodSearch = document.getElementById('food_search');
if (foodSearch) {
    foodSearch.addEventListener('input', function() {
        searchFoods(this.value);
    });
}

// Calculate nutrition percentages
function calculateMacroPercentages(protein, carbs, fat) {
    const total = protein * 4 + carbs * 4 + fat * 9;
    
    return {
        protein: ((protein * 4 / total) * 100).toFixed(1),
        carbs: ((carbs * 4 / total) * 100).toFixed(1),
        fat: ((fat * 9 / total) * 100).toFixed(1)
    };
}

// Show notification
function showNotification(message, type = 'success') {
    const alert = document.createElement('div');
    alert.className = `alert alert-${type}`;
    alert.textContent = message;
    document.querySelector('.container').insertBefore(alert, document.querySelector('.container').firstChild);
    
    setTimeout(() => alert.remove(), 3000);
}

// Update water intake
async function updateWaterIntake(amount) {
    const today = new Date().toISOString().split('T')[0];
    
    try {
        const response = await fetch(`/api/daily-nutrition/${today}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                water_intake: amount
            })
        });
        
        if (response.ok) {
            showNotification('Water intake updated! 💧', 'success');
            location.reload();
        }
    } catch (error) {
        console.error('Error updating water intake:', error);
        showNotification('Error updating water intake', 'error');
    }
}

// Export nutrition data
function exportNutritionData() {
    const data = [];
    const table = document.querySelector('table tbody');
    
    if (table) {
        table.querySelectorAll('tr').forEach(row => {
            const cells = row.querySelectorAll('td');
            data.push({
                date: cells[0].textContent,
                calories: cells[1].textContent,
                protein: cells[2].textContent,
                carbs: cells[3].textContent,
                fat: cells[4].textContent,
                water: cells[5].textContent
            });
        });
    }
    
    const csv = [
        ['Date', 'Calories', 'Protein (g)', 'Carbs (g)', 'Fat (g)', 'Water (L)'],
        ...data.map(d => [d.date, d.calories, d.protein, d.carbs, d.fat, d.water])
    ]
    .map(row => row.join(','))
    .join('\n');
    
    const link = document.createElement('a');
    link.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
    link.download = 'nutrition_data.csv';
    link.click();
}

// Validate form
function validateForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return true;
    
    const inputs = form.querySelectorAll('input[required], select[required]');
    let isValid = true;
    
    inputs.forEach(input => {
        if (!input.value) {
            input.style.borderColor = '#e63946';
            isValid = false;
        } else {
            input.style.borderColor = '';
        }
    });
    
    return isValid;
}

// Chatbot helpers
function addChatMessage(author, message, isBot = false, imageUrl = null) {
    const chatMessages = document.getElementById('chat_messages');
    if (!chatMessages) return;

    const messageItem = document.createElement('div');
    messageItem.className = `chat-message ${isBot ? 'bot' : 'user'}`;

    const bubble = document.createElement('div');
    bubble.className = 'message-bubble';
    bubble.innerHTML = `<strong>${author}</strong><p>${message.replace(/\n/g, '<br>')}</p>`;

    if (imageUrl) {
        const imageElement = document.createElement('img');
        imageElement.src = imageUrl;
        imageElement.alt = 'Uploaded image';
        imageElement.className = 'chat-image';
        bubble.appendChild(imageElement);
    }

    messageItem.appendChild(bubble);
    chatMessages.appendChild(messageItem);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function previewChatImage(input, previewEl) {
    if (!input || !previewEl) return;
    const file = input.files[0];
    if (!file) {
        previewEl.classList.add('hidden');
        previewEl.innerHTML = '';
        return;
    }
    const reader = new FileReader();
    reader.onload = function(e) {
        previewEl.classList.remove('hidden');
        previewEl.innerHTML = `
            <div class="image-preview-card">
                <img src="${e.target.result}" alt="Preview" />
                <p>${file.name}</p>
            </div>
        `;
    };
    reader.readAsDataURL(file);
}

async function initChatbot() {
    const chatForm = document.getElementById('chatbot_form');
    const chatImage = document.getElementById('chat_image');
    const previewEl = document.getElementById('image_preview');
    const chatText = document.getElementById('chat_text');
    if (!chatForm) {
        console.warn('NutriPal chatbot form not found');
        return;
    }
    console.log('NutriPal chatbot initialized');

    chatForm.addEventListener('submit', async function(event) {
        event.preventDefault();
        const text = chatText.value.trim();
        const imageFile = chatImage.files[0];
        console.log('NutriPal send:', { text, hasImage: !!imageFile });

        if (!text && !imageFile) {
            showNotification('Please enter a message or upload a photo.', 'warning');
            return;
        }

        addChatMessage('You', text || '📎 Uploaded image', false, imageFile ? URL.createObjectURL(imageFile) : null);

        const formData = new FormData();
        formData.append('text', text);
        if (imageFile) {
            formData.append('image', imageFile);
        }

        document.getElementById('chat_text').value = '';
        chatImage.value = '';
        previewEl.classList.add('hidden');
        previewEl.innerHTML = '';

        const chatMessages = document.getElementById('chat_messages');
        const loadingMessage = document.createElement('div');
        loadingMessage.className = 'chat-message bot loading-message';
        loadingMessage.innerHTML = '<div class="message-bubble">Thinking...</div>';
        chatMessages.appendChild(loadingMessage);
        chatMessages.scrollTop = chatMessages.scrollHeight;

        try {
            const response = await fetch('/api/chat', {
                method: 'POST',
                body: formData
            });

            loadingMessage.remove();
            console.log('NutriPal fetch status:', response.status);

            const contentType = response.headers.get('content-type') || '';
            if (!response.ok) {
                const text = await response.text();
                console.error('NutriPal API error response:', text);
                addChatMessage('NutriPal', 'Sorry, unable to connect to the AI assistant right now.', true);
                return;
            }

            if (!contentType.includes('application/json')) {
                const text = await response.text();
                console.error('NutriPal unexpected response:', text);
                addChatMessage('NutriPal', 'It looks like you may need to log in again. Please refresh and try again.', true);
                return;
            }

            const data = await response.json();
            console.log('NutriPal API data:', data);
            if (!data.success) {
                addChatMessage('NutriPal', data.error || 'Something went wrong while processing your request.', true);
                return;
            }

            addChatMessage('NutriPal', data.response, true, data.image_url || null);
        } catch (err) {
            loadingMessage.remove();
            addChatMessage('NutriPal', 'Oops! There was an error sending your message.', true);
            console.error('NutriPal request failed:', err);
        }
    });

    if (chatImage) {
        chatImage.addEventListener('change', function() {
            previewChatImage(this, previewEl);
        });
    }

    if (chatText) {
        chatText.addEventListener('keydown', function(event) {
            if (event.key === 'Enter' && !event.shiftKey) {
                event.preventDefault();
                chatForm.requestSubmit();
            }
        });
    }
}

// Set theme preference
function setTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
}

// Get theme preference
function getTheme() {
    return localStorage.getItem('theme') || 'light';
}

// Initialize theme
document.addEventListener('DOMContentLoaded', function() {
    setTheme(getTheme());
});
